﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace UsuarioApp
{
    public partial class MainWindow : Window
    {
        private DispatcherTimer _reloj;

        public class Usuario
        {
            public string Nombre { get; set; }
            public string UsuarioID { get; set; }
            public string Puesto { get; set; }
            public string Correo { get; set; }

            public string MostrarNombre => $"{Nombre} ({UsuarioID} - {Puesto})";
        }

        private List<Usuario> usuarios = new List<Usuario>();

        public MainWindow()
        {
            InitializeComponent();
            IniciarReloj();
            ActualizarListaUsuarios();
        }

        private void IniciarReloj()
        {
            _reloj = new DispatcherTimer();
            _reloj.Interval = TimeSpan.FromSeconds(1);
            _reloj.Tick += (s, e) =>
            {
                TxtHora.Text = DateTime.Now.ToString("hh:mm tt");
            };
            _reloj.Start();
        }

        private void BtnAgregarUsuario_Click(object sender, RoutedEventArgs e)
        {
            CerrarTodosLosPaneles();
            PanelAgregarUsuario.Visibility = Visibility.Visible;
        }

        private void BtnGuardarUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(TxtNombre.Text) &&
                !string.IsNullOrWhiteSpace(TxtUsuario.Text) &&
                !string.IsNullOrWhiteSpace(TxtCorreo.Text) &&
                !string.IsNullOrWhiteSpace(TxtPassword.Password) &&
                CmbPuesto.SelectedItem != null)
            {
                usuarios.Add(new Usuario
                {
                    Nombre = TxtNombre.Text,
                    UsuarioID = TxtUsuario.Text,
                    Correo = TxtCorreo.Text,
                    Puesto = ((ComboBoxItem)CmbPuesto.SelectedItem).Content.ToString()
                });

                TxtNombre.Clear();
                TxtUsuario.Clear();
                TxtCorreo.Clear();
                TxtPassword.Clear();
                CmbPuesto.SelectedIndex = -1;

                ActualizarListaUsuarios();
                CerrarTodosLosPaneles();
            }
            else
            {
                MessageBox.Show("Por favor completa todos los campos.", "Atención", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnEliminarUsuario_Click(object sender, RoutedEventArgs e)
        {
            CerrarTodosLosPaneles();
            PanelEliminarUsuario.Visibility = Visibility.Visible;
        }

        private void BtnEliminarUsuarioReal_Click(object sender, RoutedEventArgs e)
        {
            bool eliminado = false;

            if (!string.IsNullOrWhiteSpace(TxtEliminarUsuario.Text))
            {
                eliminado = usuarios.RemoveAll(u =>
                    u.Nombre.Trim().Equals(TxtEliminarUsuario.Text.Trim(), StringComparison.OrdinalIgnoreCase)) > 0;
            }

            else if (CmbUsuariosEliminar.SelectedItem is Usuario usuarioSeleccionado)
            {
                eliminado = usuarios.Remove(usuarioSeleccionado);
            }

            if (eliminado)
            {
                ActualizarListaUsuarios();
                TxtEliminarUsuario.Clear();
                CmbUsuariosEliminar.SelectedIndex = -1;
                CerrarTodosLosPaneles();
            }
            else
            {
                MessageBox.Show("No se encontró el usuario a eliminar.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ActualizarListaUsuarios()
        {
            ListaUsuarios.ItemsSource = null;
            ListaUsuarios.ItemsSource = usuarios;

            CmbUsuariosEliminar.ItemsSource = null;
            CmbUsuariosEliminar.ItemsSource = usuarios;
        }

        private void CerrarTodosLosPaneles()
        {
            PanelAgregarUsuario.Visibility = Visibility.Collapsed;
            PanelEliminarUsuario.Visibility = Visibility.Collapsed;
        }

        private void CerrarPaneles_Click(object sender, RoutedEventArgs e)
        {
            CerrarTodosLosPaneles();
        }
    }
}