/* script.js */
document.getElementById("flightForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    const form = event.target;
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const phone = form.phone.value.trim();
    const origin = form.origin.value;
    const destination = form.destination.value;
    const departure = form.departure.value;
    const returnDate = form.return.value;
    const passengers = form.passengers.value;
    const flightClass = form.class.value;
    
    if (!name || !email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/) || !phone.match(/^\d+$/) || !origin || !destination || origin === destination || !departure || departure < new Date().toISOString().split("T")[0] || (returnDate && returnDate <= departure) || passengers < 1 || passengers > 10) {
        alert("Por favor, complete todos los campos correctamente.");
        return;
    }
    
    alert(`Reservación confirmada:\nNombre: ${name}\nCorreo: ${email}\nTeléfono: ${phone}\nOrigen: ${origin}\nDestino: ${destination}\nFecha de salida: ${departure}\nFecha de regreso: ${returnDate || "No aplica"}\nPasajeros: ${passengers}\nClase: ${flightClass}`);
    form.reset();
});
