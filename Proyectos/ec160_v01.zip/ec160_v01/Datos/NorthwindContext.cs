// Contexto de Entity Framework para la base de datos Northwind
// Esta clase maneja la conexión y configuración de la base de datos
using Microsoft.EntityFrameworkCore;

namespace Datos
{
    public class NorthwindContext : DbContext
    {
        // Constructor que recibe las opciones de configuración del contexto
        // Permite inyectar configuraciones como la cadena de conexión
        public NorthwindContext(DbContextOptions<NorthwindContext> options) : base(options) { }


        // DbSet que representa la tabla Customers en la base de datos
        public DbSet<Customer> Customers { get; set; }

    }
} 