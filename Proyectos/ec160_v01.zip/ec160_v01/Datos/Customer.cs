// Modelo de datos que representa un cliente de la base de datos Northwind
// Esta clase define la estructura de la tabla Customers
namespace Datos
{
    public class Customer
    {
        // Clave primaria - Identificador único del cliente (máximo 5 caracteres)
        public string CustomerID { get; set; } = string.Empty;
        
        // Nombre de la empresa del cliente (campo obligatorio)
        public string CompanyName { get; set; } = string.Empty;
        
        // Nombre de la persona de contacto (puede ser nulo)
        public string? ContactName { get; set; }
        
        // Título o cargo de la persona de contacto (puede ser nulo)
        public string? ContactTitle { get; set; }
        
        // Dirección física del cliente (puede ser nulo)
        public string? Address { get; set; }
        
        // Ciudad donde se encuentra el cliente (puede ser nulo)
        public string? City { get; set; }
        
        // Región o estado del cliente (puede ser nulo)
        public string? Region { get; set; }
        
        // Código postal del cliente (puede ser nulo)
        public string? PostalCode { get; set; }
        
        // País donde se encuentra el cliente (puede ser nulo)
        public string? Country { get; set; }
        
        // Número de teléfono del cliente (puede ser nulo)
        public string? Phone { get; set; }
        
        // Número de fax del cliente (puede ser nulo)
        public string? Fax { get; set; }
    }
} 