using Microsoft.EntityFrameworkCore;
using System.Configuration;

namespace Datos
{
    public class DataCliente
    {
        // Cadena de conexión para acceder a la base de datos
        private readonly string _connectionString;

        // Constructor que obtiene la cadena de conexión desde el archivo de configuración
        public DataCliente()
        {
            _connectionString = GetConnectionString();
        }

        // Método privado para obtener la cadena de conexión desde el archivo de configuración
        private string GetConnectionString()
        {
            var connectionStringSettings = ConfigurationManager.ConnectionStrings["NorthwindConnection"];
            if (connectionStringSettings != null)
            {
                return connectionStringSettings.ConnectionString;
            }

            throw new InvalidOperationException("No se encontró la cadena de conexión 'NorthwindConnection' en el archivo de configuración.");
        }

        // Método que crea y configura el contexto para trabajar con la base de datos
        private NorthwindContext CrearContexto()
        {
            var optionsBuilder = new DbContextOptionsBuilder<NorthwindContext>();
            optionsBuilder.UseSqlServer(_connectionString);
            return new NorthwindContext(optionsBuilder.Options);
        }

        // Busca un cliente por su ID dentro de un contexto ya creado
        private Customer? BuscarClientePorId(NorthwindContext context, string customerId)
        {
            // Verifica si el ID del cliente es nulo o vacío
            if (string.IsNullOrWhiteSpace(customerId)) return null;
            // Busca el cliente en la base de datos usando LINQ
            return context.Customers.FirstOrDefault(c => c.CustomerID == customerId);
        }

        // Busca un cliente por su ID creando un nuevo contexto para ello
        public Customer? BuscarClientePorId(string customerId)
        {
            // Verifica si el ID del cliente es nulo o vacío
            using var context = CrearContexto();
            
            
            return BuscarClientePorId(context, customerId);

        }

        // Carga los datos de un cliente desde la base hacia el objeto recibido
        public bool cargarCustomer(Customer customer)
        {
            // Verifica si el objeto customer es nulo
            try
            {
                var c = BuscarClientePorId(customer.CustomerID);
                if (c == null) return false;

                // Copia cada propiedad para actualizar el objeto cliente
                customer.CompanyName = c.CompanyName;
                customer.ContactName = c.ContactName;
                customer.ContactTitle = c.ContactTitle;
                customer.Address = c.Address;
                customer.City = c.City;
                customer.Region = c.Region;
                customer.PostalCode = c.PostalCode;
                customer.Country = c.Country;
                customer.Phone = c.Phone;
                customer.Fax = c.Fax;
                return true;
            }
            catch
            {
                // En caso de error devuelve falso para evitar interrupciones
                return false;
            }
        }

        // Inserta un nuevo cliente en la base de datos
        public bool insertarCustomer(Customer customer)
        {
            // Verifica si el objeto customer es nulo
            try
            {
                using var context = CrearContexto();
                context.Customers.Add(customer);
                context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        // Elimina un cliente existente por su ID
        public bool eliminarCustomer(string customerId)
        {
            //Verifica si el ID del cliente es nulo o vacío
            try
            {
                // Si el ID es nulo o vacío, no se puede eliminar
                using var context = CrearContexto();
                var cliente = BuscarClientePorId(context, customerId);
                if (cliente == null) return false;
                // Elimina el cliente encontrado
                context.Customers.Remove(cliente);
                context.SaveChanges();
                return true;
            }
            catch
            {
                // Si ocurre un error, devuelve falso para evitar interrupciones
                return false;
            }
        }

        // Actualiza la información de un cliente existente
        public bool actualizarCustomer(Customer customer)
        {
            // Verifica si el objeto customer es nulo
            try
            {
                using var context = CrearContexto();
                var c = BuscarClientePorId(context, customer.CustomerID);
                // Si el cliente no existe, no se puede actualizar
                if (c == null) return false;

                // Si el cliente existe, actualiza sus datos
                // Actualiza los campos con los nuevos valores
                c.CompanyName = customer.CompanyName;
                c.ContactName = customer.ContactName;
                c.ContactTitle = customer.ContactTitle;
                c.Address = customer.Address;
                c.City = customer.City;
                c.Region = customer.Region;
                c.PostalCode = customer.PostalCode;
                c.Country = customer.Country;
                c.Phone = customer.Phone;
                c.Fax = customer.Fax;

               
                context.SaveChanges();
                return true;
            }
            catch
            {
                // Si ocurre un error, devuelve falso para evitar interrupciones
                return false;
            }
        }

        // Obtiene todos los clientes registrados en la base de datos
        public List<Customer> obtenerTodosLosClientes()
        {
            try
            {
                //Verifica si la cadena de conexión es válida
                using var context = CrearContexto();
                return context.Customers.ToList();
            }
            catch
            {
                // Si ocurre un error, devuelve una lista vacía para evitar fallos
                return new List<Customer>();
            }
        }
    }
}
