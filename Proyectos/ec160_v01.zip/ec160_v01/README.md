# 🏢 Sistema de Gestión de Clientes - Northwind

## 📋 ¿Qué es este proyecto?

Este es un **sistema de gestión de clientes** desarrollado en C# que te permite:
- ✅ Ver todos los clientes registrados
- ✅ Buscar un cliente específico
- ✅ Agregar nuevos clientes
- ✅ Modificar información de clientes existentes
- ✅ Eliminar clientes

## 🎯 ¿Para qué sirve?

Imagina que tienes una empresa y necesitas llevar un registro de todos tus clientes. Este sistema te ayuda a:
- **Organizar** la información de tus clientes
- **Buscar** rápidamente cualquier cliente
- **Mantener actualizada** la información de contacto
- **Eliminar** clientes que ya no trabajan contigo

## 🏗️ ¿Cómo está organizado el proyecto?

El proyecto está dividido en **3 capas** (como un edificio de 3 pisos):

### 🏢 **Piso 1: Datos (Datos)**
- **¿Qué hace?** Se encarga de hablar con la base de datos
- **Archivos importantes:**
  - `Customer.cs` - Define cómo es un cliente (nombre, teléfono, dirección, etc.)
  - `DataCliente.cs` - Maneja las operaciones con la base de datos
  - `NorthwindContext.cs` - Conecta con la base de datos

### 🏢 **Piso 2: Negocio (Negocio)**
- **¿Qué hace?** Contiene las reglas de tu negocio
- **Archivos importantes:**
  - `NegocioCliente.cs` - Maneja la lógica de negocio (validaciones, reglas)

### 🏢 **Piso 3: Presentación (ClienteCustomers)**
- **¿Qué hace?** Es la interfaz que ve el usuario
- **Archivos importantes:**
  - `Form1.cs` - La pantalla principal del programa
  - `Program.cs` - Inicia la aplicación

## 🛠️ Tecnologías utilizadas

### **Lenguaje de programación:**
- **C#** - Lenguaje principal del proyecto

### **Base de datos:**
- **SQL Server** - Base de datos donde se guardan los clientes
- **Entity Framework Core** - Herramienta para conectar C# con la base de datos

### **Interfaz de usuario:**
- **Windows Forms (WPF)** - Para crear las pantallas del programa

### **Pruebas:**
- **MSTest** - Para probar que todo funcione correctamente

### **Herramientas de desarrollo:**
- **Visual Studio** - Editor de código
- **.NET 8.0** - Plataforma de desarrollo

## 🚀 ¿Cómo usar el sistema?

### **Paso 1: Configurar la base de datos**
1. Asegúrate de tener SQL Server instalado
2. Restaura la base de datos Northwind
3. Verifica que la conexión funcione

### **Paso 2: Ejecutar el programa**
1. Abre el archivo `ClienteCustomers.sln` en Visual Studio
2. Presiona F5 o haz clic en "Ejecutar"
3. Se abrirá la ventana principal del programa

### **Paso 3: Usar las funciones**

#### **👀 Ver todos los clientes:**
- Haz clic en el botón "Cargar Clientes"
- Verás una lista con todos los clientes registrados

#### **🔍 Buscar un cliente:**
- Escribe el ID del cliente en el campo correspondiente
- Haz clic en "Buscar"
- Si existe, aparecerá su información

#### **➕ Agregar un cliente:**
- Llena todos los campos obligatorios (ID y Nombre de empresa)
- Haz clic en "Guardar"
- El sistema te dirá si se guardó correctamente

#### **✏️ Modificar un cliente:**
- Busca el cliente que quieres modificar
- Cambia la información que necesites
- Haz clic en "Actualizar"

#### **🗑️ Eliminar un cliente:**
- Busca el cliente que quieres eliminar
- Haz clic en "Eliminar"
- Confirma la eliminación

## 📁 Estructura del proyecto

```
ClienteCustomers_Final/
├── 📁 ClienteCustomers/          # Interfaz de usuario
│   ├── Form1.cs                  # Pantalla principal
│   └── Program.cs                # Punto de entrada
├── 📁 Datos/                     # Capa de datos
│   ├── Customer.cs               # Modelo de cliente
│   ├── DataCliente.cs            # Operaciones con BD
│   └── NorthwindContext.cs       # Conexión a BD
├── 📁 Negocio/                   # Capa de negocio
│   └── NegocioCliente.cs         # Lógica de negocio
├── 📁 Pruebas Basicas/           # Pruebas del sistema
│   └── NegocioClienteMSTest.cs   # Pruebas unitarias
└── 📄 ClienteCustomers.sln        # Archivo principal del proyecto
```

## ⚙️ Configuración de la base de datos

### **Archivo de configuración: `App.config`**
```xml
<connectionStrings>
  <add name="NorthwindConnection" 
       connectionString="Server=localhost\SQLEXPRESS;Database=Northwind;Trusted_Connection=True;" 
       providerName="System.Data.SqlClient" />
</connectionStrings>
```

### **¿Cómo cambiar la conexión?**
Si tu base de datos está en otro servidor, modifica la cadena de conexión en `App.config`:
- Cambia `localhost\SQLEXPRESS` por tu servidor
- Cambia `Northwind` por el nombre de tu base de datos

## 🧪 Pruebas del sistema

El proyecto incluye pruebas automáticas que verifican que todo funcione correctamente:

### **Ejecutar las pruebas:**
1. Abre el "Explorador de pruebas" en Visual Studio
2. Haz clic en "Ejecutar todas las pruebas"
3. Verifica que todas las pruebas pasen (estado verde)

### **Tipos de pruebas:**
- ✅ **Pruebas de inserción** - Verifican que se puedan agregar clientes
- ✅ **Pruebas de búsqueda** - Verifican que se puedan encontrar clientes
- ✅ **Pruebas de actualización** - Verifican que se puedan modificar clientes
- ✅ **Pruebas de eliminación** - Verifican que se puedan eliminar clientes

## 🔧 Requisitos del sistema

### **Para ejecutar el programa:**
- Windows 10 o superior
- .NET 8.0 Runtime
- SQL Server (cualquier versión reciente)

### **Para modificar el código:**
- Visual Studio 2022
- .NET 8.0 SDK
- SQL Server Management Studio (opcional)

## 📞 Soporte y ayuda

### **Si tienes problemas:**
1. **Error de conexión:** Verifica que SQL Server esté ejecutándose
2. **Base de datos no encontrada:** Asegúrate de que la base de datos Northwind esté instalada
3. **Permisos:** Verifica que tengas permisos para acceder a la base de datos

### **Mensajes de error comunes:**
- **"No se encontró la cadena de conexión"** → Revisa el archivo App.config
- **"Cliente no encontrado"** → Verifica que el ID del cliente sea correcto
- **"El CustomerID es obligatorio"** → Debes llenar el campo ID del cliente

## 🎓 ¿Qué aprendes con este proyecto?

Este proyecto te enseña:
- **Arquitectura de 3 capas** - Cómo organizar código profesional
- **Entity Framework** - Cómo conectar C# con bases de datos
- **Windows Forms** - Cómo crear interfaces de usuario
- **Pruebas unitarias** - Cómo probar tu código
- **Buenas prácticas** - Cómo escribir código limpio y mantenible

## 🚀 Próximos pasos

Si quieres mejorar el proyecto, puedes:
- Agregar más validaciones
- Crear reportes de clientes
- Implementar búsquedas avanzadas
- Agregar más campos al cliente
- Crear una interfaz web

---

**¡Disfruta usando tu sistema de gestión de clientes! 🎉**
