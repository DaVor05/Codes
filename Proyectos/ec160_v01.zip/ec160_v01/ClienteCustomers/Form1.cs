using Negocio;


namespace ClienteCustomers
{
    public partial class Form1 : Form
    {
        // Cuando se crea el formulario, carga todos los clientes
        public Form1()
        {
            // Inicializa los componentes del formulario y carga los clientes
            InitializeComponent();
                        Theme.Apply(this);
CargarTodosLosClientes();
        }

        // Trae la lista de todos los clientes y la muestra en la tabla
        private void CargarTodosLosClientes()
        {

            try
            {
                // Crea una instancia de NegocioCliente y obtiene todos los clientes
                var cliente = new NegocioCliente();
                var clientes = cliente.obtenerTodos();
                dgvClientes.DataSource = clientes;
                MostrarMensaje($"Se cargaron {clientes.Count} clientes correctamente", Color.Green);
            }
            catch (Exception ex)
            {
                MostrarMensaje($"Error al cargar clientes: {ex.Message}", Color.Red);
            }
        }

        // Cuando se hace clic en Insertar, crea un cliente con los datos del formulario y lo guarda
        private void btnInsertar_Click(object sender, EventArgs e)
        {
            // Crea un nuevo cliente con los datos del formulario
            var cliente = ConstruirClienteDesdeFormulario();
            if (cliente.insertar(out string mensaje))
            {
                // Si se insertó correctamente, muestra un mensaje y limpia los campos
                MostrarMensaje(mensaje, Color.Green);
                LimpiarCampos();
                CargarTodosLosClientes();
            }
            else
            {
                // Si hubo un error al insertar, muestra el mensaje de error
                MostrarMensaje(mensaje, Color.Red);
            }
        }

        // Cuando se hace clic en Eliminar, elimina el cliente que tenga el ID indicado
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            // Crea un nuevo cliente solo con el ID para eliminarlo
            var cliente = new NegocioCliente { CustomerID = txtIdCliente.Text.Trim() };

            if (string.IsNullOrWhiteSpace(cliente.CustomerID))
            {
                MostrarMensaje("Ingresa el ID del cliente para eliminar", Color.Red);
                txtIdCliente.Focus();
                return;
            }

            // Pregunta si estás seguro antes de borrar
            var confirm = MessageBox.Show(
                $"¿Seguro que quieres eliminar al cliente '{cliente.CustomerID}'?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes)
            {
                MostrarMensaje("Eliminación cancelada", Color.Blue);
                return;
            }

            if (cliente.eliminar(out string mensaje))
            {
                MostrarMensaje(mensaje, Color.Green);
                LimpiarCampos();
                CargarTodosLosClientes();
            }
            else
            {
                MostrarMensaje(mensaje, Color.Red);
            }
        }

        // Cuando se hace clic en Consultar, busca el cliente y muestra sus datos en el formulario
        private void btnConsultar_Click(object sender, EventArgs e)
        {
            var cliente = new NegocioCliente { CustomerID = txtIdCliente.Text.Trim() };

            if (cliente.cargar(out string mensaje))
            {
                txtNombreEmpresa.Text = cliente.CompanyName ?? "";
                txtNombreContacto.Text = cliente.ContactName ?? "";
                txtCargoContacto.Text = cliente.ContactTitle ?? "";
                txtDireccion.Text = cliente.Address ?? "";
                txtCiudad.Text = cliente.City ?? "";
                txtRegion.Text = cliente.Region ?? "";
                txtCodigoPostal.Text = cliente.PostalCode ?? "";
                txtPais.Text = cliente.Country ?? "";
                txtTelefono.Text = cliente.Phone ?? "";
                txtFax.Text = cliente.Fax ?? "";

                MostrarMensaje(mensaje, Color.Green);
            }
            else
            {
                MostrarMensaje(mensaje, Color.Red);
            }
        }

        // Cuando se hace clic en Actualizar, guarda los cambios en el cliente
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            var cliente = ConstruirClienteDesdeFormulario();
            if (cliente.actualizar(out string mensaje))
            {
                MostrarMensaje(mensaje, Color.Green);
                CargarTodosLosClientes();
            }
            else
            {
                MostrarMensaje(mensaje, Color.Red);
            }
        }

        // Limpia todos los campos del formulario
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            MostrarMensaje("Campos limpiados", Color.Blue);
        }

        // Refresca la lista de clientes que se muestra
        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            CargarTodosLosClientes();
            MostrarMensaje("Lista de clientes actualizada", Color.Green);
        }

        // Muestra un mensaje en pantalla con el color que se pase
        private void MostrarMensaje(string mensaje, Color color)
        {
            lblMensajeEstado.Text = mensaje;
            lblMensajeEstado.ForeColor = color;
        }

        // Borra los textos de todos los campos para que estén vacíos
        private void LimpiarCampos()
        {
            txtIdCliente.Text = "";
            txtNombreEmpresa.Text = "";
            txtNombreContacto.Text = "";
            txtCargoContacto.Text = "";
            txtDireccion.Text = "";
            txtCiudad.Text = "";
            txtRegion.Text = "";
            txtCodigoPostal.Text = "";
            txtPais.Text = "";
            txtTelefono.Text = "";
            txtFax.Text = "";
        }

        // Crea un cliente con los datos que se hayan escrito en el formulario
        private NegocioCliente ConstruirClienteDesdeFormulario()
        {
            return new NegocioCliente
            {
                CustomerID = txtIdCliente.Text.Trim(),
                CompanyName = txtNombreEmpresa.Text.Trim(),
                ContactName = txtNombreContacto.Text.Trim(),
                ContactTitle = txtCargoContacto.Text.Trim(),
                Address = txtDireccion.Text.Trim(),
                City = txtCiudad.Text.Trim(),
                Region = txtRegion.Text.Trim(),
                PostalCode = txtCodigoPostal.Text.Trim(),
                Country = txtPais.Text.Trim(),
                Phone = txtTelefono.Text.Trim(),
                Fax = txtFax.Text.Trim()
            };
        }
    }
}
