﻿using Datos;

namespace ClienteCustomers
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvClientes;
        private System.Windows.Forms.Label lblIdCliente;
        private System.Windows.Forms.TextBox txtIdCliente;
        private System.Windows.Forms.Label lblNombreEmpresa;
        private System.Windows.Forms.TextBox txtNombreEmpresa;
        private System.Windows.Forms.Label lblNombreContacto;
        private System.Windows.Forms.TextBox txtNombreContacto;
        private System.Windows.Forms.Label lblCargoContacto;
        private System.Windows.Forms.TextBox txtCargoContacto;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Label lblCiudad;
        private System.Windows.Forms.TextBox txtCiudad;
        private System.Windows.Forms.Label lblRegion;
        private System.Windows.Forms.TextBox txtRegion;
        private System.Windows.Forms.Label lblCodigoPostal;
        private System.Windows.Forms.TextBox txtCodigoPostal;
        private System.Windows.Forms.Label lblPais;
        private System.Windows.Forms.TextBox txtPais;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.Label lblFax;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Button btnAgregarCliente;
        private System.Windows.Forms.Button btnEliminarCliente;
        private System.Windows.Forms.Button btnBuscarCliente;
        private System.Windows.Forms.Button btnModificarCliente;
        private System.Windows.Forms.Button btnLimpiarFormulario;
        private System.Windows.Forms.Button btnActualizarLista;
        private System.Windows.Forms.Label lblMensajeEstado;
        private System.Windows.Forms.Label lblTituloPrincipal;
        private System.Windows.Forms.GroupBox gbDatosCliente;
        private System.Windows.Forms.GroupBox gbAccionesCliente;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            dgvClientes = new DataGridView();
            lblIdCliente = new Label();
            txtIdCliente = new TextBox();
            lblNombreEmpresa = new Label();
            txtNombreEmpresa = new TextBox();
            lblNombreContacto = new Label();
            txtNombreContacto = new TextBox();
            lblCargoContacto = new Label();
            txtCargoContacto = new TextBox();
            lblDireccion = new Label();
            txtDireccion = new TextBox();
            lblCiudad = new Label();
            txtCiudad = new TextBox();
            lblRegion = new Label();
            txtRegion = new TextBox();
            lblCodigoPostal = new Label();
            txtCodigoPostal = new TextBox();
            lblPais = new Label();
            txtPais = new TextBox();
            lblTelefono = new Label();
            txtTelefono = new TextBox();
            lblFax = new Label();
            txtFax = new TextBox();
            btnAgregarCliente = new Button();
            btnEliminarCliente = new Button();
            btnBuscarCliente = new Button();
            btnModificarCliente = new Button();
            btnLimpiarFormulario = new Button();
            btnActualizarLista = new Button();
            lblMensajeEstado = new Label();
            lblTituloPrincipal = new Label();
            gbDatosCliente = new GroupBox();
            gbAccionesCliente = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)dgvClientes).BeginInit();
            gbDatosCliente.SuspendLayout();
            gbAccionesCliente.SuspendLayout();
            SuspendLayout();
            // 
            // dgvClientes
            // 
            dgvClientes.AllowUserToAddRows = false;
            dgvClientes.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.AliceBlue;
            dgvClientes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgvClientes.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvClientes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            dgvClientes.BackgroundColor = Color.White;
            dgvClientes.BorderStyle = BorderStyle.Fixed3D;
            dgvClientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvClientes.Location = new Point(12, 420);
            dgvClientes.Name = "dgvClientes";
            dgvClientes.ReadOnly = true;
            dgvClientes.RowHeadersVisible = false;
            dgvClientes.RowTemplate.Height = 25;
            dgvClientes.ScrollBars = ScrollBars.Both;
            dgvClientes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvClientes.Size = new Size(760, 220);
            dgvClientes.TabIndex = 0;
            dgvClientes.AllowUserToResizeColumns = true;
            // 
            // lblIdCliente
            // 
            lblIdCliente.Location = new Point(20, 30);
            lblIdCliente.Name = "lblIdCliente";
            lblIdCliente.Size = new Size(120, 20);
            lblIdCliente.TabIndex = 1;
            lblIdCliente.Text = "ID Cliente:";
            lblIdCliente.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtIdCliente
            // 
            txtIdCliente.Location = new Point(145, 28);
            txtIdCliente.Name = "txtIdCliente";
            txtIdCliente.Size = new Size(200, 23);
            txtIdCliente.TabIndex = 2;
            // 
            // lblNombreEmpresa
            // 
            lblNombreEmpresa.Location = new Point(20, 58);
            lblNombreEmpresa.Name = "lblNombreEmpresa";
            lblNombreEmpresa.Size = new Size(120, 20);
            lblNombreEmpresa.TabIndex = 3;
            lblNombreEmpresa.Text = "Empresa:";
            lblNombreEmpresa.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtNombreEmpresa
            // 
            txtNombreEmpresa.Location = new Point(145, 56);
            txtNombreEmpresa.Name = "txtNombreEmpresa";
            txtNombreEmpresa.Size = new Size(200, 23);
            txtNombreEmpresa.TabIndex = 4;
            // 
            // lblNombreContacto
            // 
            lblNombreContacto.Location = new Point(20, 86);
            lblNombreContacto.Name = "lblNombreContacto";
            lblNombreContacto.Size = new Size(120, 20);
            lblNombreContacto.TabIndex = 5;
            lblNombreContacto.Text = "Contacto:";
            lblNombreContacto.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtNombreContacto
            // 
            txtNombreContacto.Location = new Point(145, 84);
            txtNombreContacto.Name = "txtNombreContacto";
            txtNombreContacto.Size = new Size(200, 23);
            txtNombreContacto.TabIndex = 6;
            // 
            // lblCargoContacto
            // 
            lblCargoContacto.Location = new Point(20, 114);
            lblCargoContacto.Name = "lblCargoContacto";
            lblCargoContacto.Size = new Size(120, 20);
            lblCargoContacto.TabIndex = 7;
            lblCargoContacto.Text = "Cargo:";
            lblCargoContacto.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtCargoContacto
            // 
            txtCargoContacto.Location = new Point(145, 112);
            txtCargoContacto.Name = "txtCargoContacto";
            txtCargoContacto.Size = new Size(200, 23);
            txtCargoContacto.TabIndex = 8;
            // 
            // lblDireccion
            // 
            lblDireccion.Location = new Point(20, 142);
            lblDireccion.Name = "lblDireccion";
            lblDireccion.Size = new Size(120, 20);
            lblDireccion.TabIndex = 9;
            lblDireccion.Text = "Dirección:";
            lblDireccion.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new Point(145, 140);
            txtDireccion.Name = "txtDireccion";
            txtDireccion.Size = new Size(200, 23);
            txtDireccion.TabIndex = 10;
            // 
            // lblCiudad
            // 
            lblCiudad.Location = new Point(20, 170);
            lblCiudad.Name = "lblCiudad";
            lblCiudad.Size = new Size(120, 20);
            lblCiudad.TabIndex = 11;
            lblCiudad.Text = "Ciudad:";
            lblCiudad.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtCiudad
            // 
            txtCiudad.Location = new Point(145, 168);
            txtCiudad.Name = "txtCiudad";
            txtCiudad.Size = new Size(200, 23);
            txtCiudad.TabIndex = 12;
            // 
            // lblRegion
            // 
            lblRegion.Location = new Point(380, 30);
            lblRegion.Name = "lblRegion";
            lblRegion.Size = new Size(120, 20);
            lblRegion.TabIndex = 13;
            lblRegion.Text = "Región:";
            lblRegion.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtRegion
            // 
            txtRegion.Location = new Point(505, 28);
            txtRegion.Name = "txtRegion";
            txtRegion.Size = new Size(200, 23);
            txtRegion.TabIndex = 14;
            // 
            // lblCodigoPostal
            // 
            lblCodigoPostal.Location = new Point(380, 58);
            lblCodigoPostal.Name = "lblCodigoPostal";
            lblCodigoPostal.Size = new Size(120, 20);
            lblCodigoPostal.TabIndex = 15;
            lblCodigoPostal.Text = "Código Postal:";
            lblCodigoPostal.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtCodigoPostal
            // 
            txtCodigoPostal.Location = new Point(505, 56);
            txtCodigoPostal.Name = "txtCodigoPostal";
            txtCodigoPostal.Size = new Size(200, 23);
            txtCodigoPostal.TabIndex = 16;
            // 
            // lblPais
            // 
            lblPais.Location = new Point(380, 86);
            lblPais.Name = "lblPais";
            lblPais.Size = new Size(120, 20);
            lblPais.TabIndex = 17;
            lblPais.Text = "País:";
            lblPais.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtPais
            // 
            txtPais.Location = new Point(505, 84);
            txtPais.Name = "txtPais";
            txtPais.Size = new Size(200, 23);
            txtPais.TabIndex = 18;
            // 
            // lblTelefono
            // 
            lblTelefono.Location = new Point(380, 114);
            lblTelefono.Name = "lblTelefono";
            lblTelefono.Size = new Size(120, 20);
            lblTelefono.TabIndex = 19;
            lblTelefono.Text = "Teléfono:";
            lblTelefono.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(505, 112);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(200, 23);
            txtTelefono.TabIndex = 20;
            // 
            // lblFax
            // 
            lblFax.Location = new Point(380, 142);
            lblFax.Name = "lblFax";
            lblFax.Size = new Size(120, 20);
            lblFax.TabIndex = 21;
            lblFax.Text = "Fax:";
            lblFax.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtFax
            // 
            txtFax.Location = new Point(505, 140);
            txtFax.Name = "txtFax";
            txtFax.Size = new Size(200, 23);
            txtFax.TabIndex = 22;
            // 
            // btnAgregarCliente
            // 
            btnAgregarCliente.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnAgregarCliente.Location = new Point(30, 25);
            btnAgregarCliente.Name = "btnAgregarCliente";
            btnAgregarCliente.Size = new Size(120, 35);
            btnAgregarCliente.TabIndex = 23;
            btnAgregarCliente.Text = "Agregar";
            btnAgregarCliente.UseVisualStyleBackColor = true;
            btnAgregarCliente.Click += btnInsertar_Click;
            // 
            // btnEliminarCliente
            // 
            btnEliminarCliente.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnEliminarCliente.Location = new Point(160, 25);
            btnEliminarCliente.Name = "btnEliminarCliente";
            btnEliminarCliente.Size = new Size(120, 35);
            btnEliminarCliente.TabIndex = 24;
            btnEliminarCliente.Text = "Eliminar";
            btnEliminarCliente.UseVisualStyleBackColor = true;
            btnEliminarCliente.Click += btnEliminar_Click;
            // 
            // btnBuscarCliente
            // 
            btnBuscarCliente.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnBuscarCliente.Location = new Point(290, 25);
            btnBuscarCliente.Name = "btnBuscarCliente";
            btnBuscarCliente.Size = new Size(120, 35);
            btnBuscarCliente.TabIndex = 25;
            btnBuscarCliente.Text = "Buscar";
            btnBuscarCliente.UseVisualStyleBackColor = true;
            btnBuscarCliente.Click += btnConsultar_Click;
            // 
            // btnModificarCliente
            // 
            btnModificarCliente.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnModificarCliente.Location = new Point(420, 25);
            btnModificarCliente.Name = "btnModificarCliente";
            btnModificarCliente.Size = new Size(120, 35);
            btnModificarCliente.TabIndex = 26;
            btnModificarCliente.Text = "Modificar";
            btnModificarCliente.UseVisualStyleBackColor = true;
            btnModificarCliente.Click += btnActualizar_Click;
            // 
            // btnLimpiarFormulario
            // 
            btnLimpiarFormulario.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnLimpiarFormulario.Location = new Point(550, 25);
            btnLimpiarFormulario.Name = "btnLimpiarFormulario";
            btnLimpiarFormulario.Size = new Size(120, 35);
            btnLimpiarFormulario.TabIndex = 27;
            btnLimpiarFormulario.Text = "Limpiar";
            btnLimpiarFormulario.UseVisualStyleBackColor = true;
            btnLimpiarFormulario.Click += btnLimpiar_Click;
            // 
            // btnActualizarLista
            // 
            btnActualizarLista.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnActualizarLista.ForeColor = SystemColors.ControlText;
            btnActualizarLista.Location = new Point(290, 65);
            btnActualizarLista.Name = "btnActualizarLista";
            btnActualizarLista.Size = new Size(180, 25);
            btnActualizarLista.TabIndex = 28;
            btnActualizarLista.Text = "Actualizar Lista";
            btnActualizarLista.UseVisualStyleBackColor = true;
            btnActualizarLista.Click += btnRefrescar_Click;
            // 
            // lblMensajeEstado
            // 
            lblMensajeEstado.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblMensajeEstado.Font = new Font("Segoe UI", 9F);
            lblMensajeEstado.ForeColor = Color.Blue;
            lblMensajeEstado.Location = new Point(12, 385);
            lblMensajeEstado.Name = "lblMensajeEstado";
            lblMensajeEstado.Size = new Size(760, 25);
            lblMensajeEstado.TabIndex = 29;
            lblMensajeEstado.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblTituloPrincipal
            // 
            lblTituloPrincipal.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblTituloPrincipal.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblTituloPrincipal.Location = new Point(12, 12);
            lblTituloPrincipal.Name = "lblTituloPrincipal";
            lblTituloPrincipal.Size = new Size(760, 40);
            lblTituloPrincipal.TabIndex = 0;
            lblTituloPrincipal.Text = "Gestión de Clientes Northwind";
            lblTituloPrincipal.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // gbDatosCliente
            // 
            gbDatosCliente.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            gbDatosCliente.BackColor = Color.WhiteSmoke;
            gbDatosCliente.Controls.Add(lblIdCliente);
            gbDatosCliente.Controls.Add(txtIdCliente);
            gbDatosCliente.Controls.Add(lblNombreEmpresa);
            gbDatosCliente.Controls.Add(txtNombreEmpresa);
            gbDatosCliente.Controls.Add(lblNombreContacto);
            gbDatosCliente.Controls.Add(txtNombreContacto);
            gbDatosCliente.Controls.Add(lblCargoContacto);
            gbDatosCliente.Controls.Add(txtCargoContacto);
            gbDatosCliente.Controls.Add(lblDireccion);
            gbDatosCliente.Controls.Add(txtDireccion);
            gbDatosCliente.Controls.Add(lblCiudad);
            gbDatosCliente.Controls.Add(txtCiudad);
            gbDatosCliente.Controls.Add(lblRegion);
            gbDatosCliente.Controls.Add(txtRegion);
            gbDatosCliente.Controls.Add(lblCodigoPostal);
            gbDatosCliente.Controls.Add(txtCodigoPostal);
            gbDatosCliente.Controls.Add(lblPais);
            gbDatosCliente.Controls.Add(txtPais);
            gbDatosCliente.Controls.Add(lblTelefono);
            gbDatosCliente.Controls.Add(txtTelefono);
            gbDatosCliente.Controls.Add(lblFax);
            gbDatosCliente.Controls.Add(txtFax);
            gbDatosCliente.Font = new Font("Segoe UI", 9F);
            gbDatosCliente.Location = new Point(12, 65);
            gbDatosCliente.Name = "gbDatosCliente";
            gbDatosCliente.Size = new Size(760, 200);
            gbDatosCliente.TabIndex = 1;
            gbDatosCliente.TabStop = false;
            gbDatosCliente.Text = "Datos del Cliente";
            // 
            // gbAccionesCliente
            // 
            gbAccionesCliente.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            gbAccionesCliente.Controls.Add(btnAgregarCliente);
            gbAccionesCliente.Controls.Add(btnEliminarCliente);
            gbAccionesCliente.Controls.Add(btnBuscarCliente);
            gbAccionesCliente.Controls.Add(btnModificarCliente);
            gbAccionesCliente.Controls.Add(btnLimpiarFormulario);
            gbAccionesCliente.Controls.Add(btnActualizarLista);
            gbAccionesCliente.Font = new Font("Segoe UI", 9F);
            gbAccionesCliente.Location = new Point(12, 275);
            gbAccionesCliente.Name = "gbAccionesCliente";
            gbAccionesCliente.Size = new Size(760, 100);
            gbAccionesCliente.TabIndex = 2;
            gbAccionesCliente.TabStop = false;
            gbAccionesCliente.Text = "Acciones";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(784, 661);
            Controls.Add(lblTituloPrincipal);
            Controls.Add(gbDatosCliente);
            Controls.Add(gbAccionesCliente);
            Controls.Add(lblMensajeEstado);
            Controls.Add(dgvClientes);
            MinimumSize = new Size(800, 700);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Gestión de Clientes Northwind";
            ((System.ComponentModel.ISupportInitialize)dgvClientes).EndInit();
            gbDatosCliente.ResumeLayout(false);
            gbDatosCliente.PerformLayout();
            gbAccionesCliente.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
    }
}
