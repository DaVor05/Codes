
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ClienteCustomers
{
    public static class Theme
    {
        // Paleta de colores (puedes cambiar a tu gusto)
        public static Color Primary   = Color.FromArgb(58, 134, 255);   // Azul vivo
        public static Color Secondary = Color.FromArgb(255, 99, 132);   // Rosa/rojo suave
        public static Color Accent    = Color.FromArgb(255, 206, 86);   // Amarillo
        public static Color Surface   = Color.FromArgb(245, 247, 250);  // Gris muy claro
        public static Color TextDark  = Color.FromArgb(33, 37, 41);
        public static Color TextLight = Color.White;

        public static void Apply(Form form)
        {
            form.BackColor = Surface;
            form.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

            foreach (Control c in form.Controls)
            {
                StyleControl(c);
            }
        }

        private static void StyleControl(Control c)
        {
            if (c is GroupBox gb)
            {
                gb.BackColor = Surface;
                gb.ForeColor = TextDark;
                gb.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            }
            else if (c is Label lbl)
            {
                lbl.ForeColor = TextDark;
            }
            else if (c is TextBox tb)
            {
                tb.BorderStyle = BorderStyle.FixedSingle;
                tb.BackColor = Color.White;
            }
            else if (c is Button btn)
            {
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 0;
                btn.BackColor = Primary;
                btn.ForeColor = TextLight;
                btn.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
                btn.Padding = new Padding(6, 3, 6, 3);
            }
            else if (c is DataGridView dgv)
            {
                dgv.EnableHeadersVisualStyles = false;
                dgv.BackgroundColor = Surface;
                dgv.BorderStyle = BorderStyle.None;
                dgv.GridColor = Color.FromArgb(230, 235, 240);

                var alt = new DataGridViewCellStyle();
                alt.BackColor = Color.FromArgb(240, 244, 248);
                dgv.AlternatingRowsDefaultCellStyle = alt;

                var header = new DataGridViewCellStyle();
                header.BackColor = Primary;
                header.ForeColor = TextLight;
                header.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
                dgv.ColumnHeadersDefaultCellStyle = header;

                dgv.DefaultCellStyle.SelectionBackColor = Secondary;
                dgv.DefaultCellStyle.SelectionForeColor = TextLight;
            }

            // Recurse
            foreach (Control child in c.Controls)
                StyleControl(child);
        }
    }
}
