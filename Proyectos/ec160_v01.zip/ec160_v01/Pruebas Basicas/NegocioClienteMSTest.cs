using Negocio;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Pruebas_Basicas
{
    /// <summary>
    /// Pruebas unitarias para la clase NegocioCliente usando MSTest
    /// Implementadas según la tabla de especificaciones funcionales
    /// </summary>
    [TestClass]
    public class NegocioClienteMSTest
    {
        // Clase de pruebas para NegocioCliente
        private NegocioCliente _negocioCliente;
        // ID de cliente de prueba generado dinámicamente para evitar conflictos
        private string _testCustomerId;

        [TestInitialize]
        public void Setup()
        {
            // Inicializar la instancia de NegocioCliente antes de cada prueba
            _negocioCliente = new NegocioCliente();
            // Generar ID único más robusto para evitar conflictos
            var timestamp = DateTime.Now.Ticks;
            var random = new Random();
            var randomNum = random.Next(1000, 9999);
            _testCustomerId = $"T{timestamp % 10000:D4}{randomNum:D4}".Substring(0, 5);
            
            // Limpiar cualquier dato residual antes de empezar
            CleanupResidualData();
        }

        [TestCleanup]
        public void Cleanup()
        {
            // Limpiar datos de prueba de la BD real
            CleanupResidualData();
        }

        private void CleanupResidualData()
        {
            try
            {
                if (!string.IsNullOrEmpty(_testCustomerId))
                {
                    var clienteLimpieza = new NegocioCliente { CustomerID = _testCustomerId };
                    clienteLimpieza.eliminar(out string mensaje);
                    
                    // También limpiar variaciones del ID por si acaso
                    var idVariations = new[] 
                    { 
                        _testCustomerId, 
                        _testCustomerId + "1", 
                        _testCustomerId + "2" 
                    };
                    
                    foreach (var id in idVariations)
                    {
                        try
                        {
                            var clienteExtra = new NegocioCliente { CustomerID = id };
                            clienteExtra.eliminar(out string _);
                        }
                        catch
                        {
                            // Ignorar errores de limpieza extra
                        }
                    }
                }
            }
            catch
            {
                // Ignorar errores de limpieza
            }
        }

        /// <summary>
        /// Caso de Prueba #1: Insertar cliente exitosamente
        /// Componente: Insertar()
        /// Valores de Entrada: Datos válidos de cliente (nombre, dirección, etc.)
        /// Valor de Salida Esperada: Cliente insertado correctamente.
        /// ¿Ejecución Exitosa?: Sí
        /// Tipo de Error Detectado: Ninguno
        /// Comentarios: Si la inserción es exitosa, el sistema muestra un mensaje de confirmación y limpia los campos utilizados en el formulario.
        /// </summary>
        [TestMethod]
        public void CP_001_InsertarClienteExitosamente()
        {
            // Arrange - Configurar datos válidos de cliente
            _negocioCliente.CustomerID = _testCustomerId;
            _negocioCliente.CompanyName = "Empresa de Prueba";

            // Verificar que el cliente no existe antes de insertar
            var clienteVerificacion = new NegocioCliente { CustomerID = _testCustomerId };
            var existeAntes = clienteVerificacion.cargar(out string mensajeVerificacion);
            if (existeAntes)
            {
                // Si existe, eliminarlo primero
                clienteVerificacion.eliminar(out string mensajeEliminacion);
            }

            // Act - Ejecutar inserción
            bool resultado = _negocioCliente.insertar(out string mensaje);

            // Assert - Verificar éxito (permitir ambos mensajes posibles)
            Assert.IsTrue(resultado, $"La inserción falló. Mensaje: {mensaje}");
            Assert.IsTrue(mensaje.Contains("insertado") || mensaje.Contains("correctamente"), 
                $"Mensaje inesperado: {mensaje}");
        }

        /// <summary>
        /// Caso de Prueba #2: Insertar cliente con datos inválidos
        /// Componente: Insertar()
        /// Valores de Entrada: Datos inválidos o incompletos
        /// Valor de Salida Esperada: No se pudo insertar el cliente.
        /// ¿Ejecución Exitosa?: No
        /// Tipo de Error Detectado: Validación de datos.
        /// Comentarios: Si faltan campos obligatorios, no es posible realizar la inserción. El sistema muestra un mensaje de error indicando los campos requeridos, como el ID del cliente
        /// </summary>
        [TestMethod]
        public void CP_002_InsertarClienteConDatosInvalidos()
        {
            // Arrange - Configurar datos inválidos o incompletos
            _negocioCliente.CustomerID = "";
            _negocioCliente.CompanyName = "Empresa de Prueba";

            // Act - Ejecutar inserción
            bool resultado = _negocioCliente.insertar(out string mensaje);

            // Assert - Verificar fallo
            Assert.IsFalse(resultado);
            Assert.AreEqual("El CustomerID es obligatorio.", mensaje);
        }

        /// <summary>
        /// Caso de Prueba #3: Eliminar cliente existente
        /// Componente: Eliminar()
        /// Valores de Entrada: CustomerID existente
        /// Valor de Salida Esperada: Cliente eliminado correctamente
        /// ¿Ejecución Exitosa?: Sí
        /// Tipo de Error Detectado: Dependecias de llaves foraneas.
        /// Comentarios: El cliente se elimina correctamente si los datos son válidos. Si existen relaciones dependientes, la eliminación no se permite hasta que estas sean eliminadas.
        /// </summary>
        [TestMethod]
        public void CP_003_EliminarClienteExistente()
        {
            // Arrange - Primero insertar un cliente para luego eliminarlo
            _negocioCliente.CustomerID = _testCustomerId;
            _negocioCliente.CompanyName = "Empresa para Eliminar";
            bool insertado = _negocioCliente.insertar(out string mensajeInsercion);
            
            // Si la inserción falla, saltar la prueba (problema de BD)
            if (!insertado)
            {
                Assert.Inconclusive($"No se pudo insertar cliente para prueba de eliminación. Mensaje: {mensajeInsercion}");
                return;
            }

            // Act - Ejecutar eliminación
            bool resultado = _negocioCliente.eliminar(out string mensaje);

            // Assert - Verificar éxito
            Assert.IsTrue(resultado, $"La eliminación falló. Mensaje: {mensaje}");
            Assert.IsTrue(mensaje.Contains("eliminado") || mensaje.Contains("correctamente"), 
                $"Mensaje inesperado: {mensaje}");
        }

        /// <summary>
        /// Caso de Prueba #4: Eliminar cliente inexistente
        /// Componente: Eliminar()
        /// Valores de Entrada: CustomerID no registrado
        /// Valor de Salida Esperada: No se pudo eliminar el cliente.
        /// ¿Ejecución Exitosa?: No
        /// Tipo de Error Detectado: Ninguno.
        /// Comentarios: Si se intenta eliminar un usuario no registrado en la base de datos, se genera un mensaje de error y la operación de eliminación se cancela.
        /// </summary>
        [TestMethod]
        public void CP_004_EliminarClienteInexistente()
        {
            // Arrange - Configurar CustomerID no registrado
            _negocioCliente.CustomerID = "XXXXX";

            // Act - Ejecutar eliminación
            bool resultado = _negocioCliente.eliminar(out string mensaje);

            // Assert - Verificar fallo
            Assert.IsFalse(resultado);
            Assert.AreEqual("No se pudo eliminar el cliente.", mensaje);
        }

        /// <summary>
        /// Caso de Prueba #5: Consultar cliente existente
        /// Componente: Cargar()
        /// Valores de Entrada: CustomerID existente
        /// Valor de Salida Esperada: Información del cliente cargada correctamente.
        /// ¿Ejecución Exitosa?: Sí
        /// Tipo de Error Detectado: Ninguno.
        /// Comentarios: Cuando se ingresa un usuario previamente registrado, los campos correspondientes se cargan correctamente.
        /// </summary>
        [TestMethod]
        public void CP_005_ConsultarClienteExistente()
        {
            // Arrange - Primero insertar un cliente para luego consultarlo
            _negocioCliente.CustomerID = _testCustomerId;
            _negocioCliente.CompanyName = "Empresa para Consultar";
            bool insertado = _negocioCliente.insertar(out string mensajeInsercion);
            
            // Si la inserción falla, saltar la prueba (problema de BD)
            if (!insertado)
            {
                Assert.Inconclusive($"No se pudo insertar cliente para prueba de consulta. Mensaje: {mensajeInsercion}");
                return;
            }

            // Crear nueva instancia para consultar
            var clienteParaConsultar = new NegocioCliente { CustomerID = _testCustomerId };

            // Act - Ejecutar consulta
            bool resultado = clienteParaConsultar.cargar(out string mensaje);

            // Assert - Verificar éxito
            Assert.IsTrue(resultado, $"La consulta falló. Mensaje: {mensaje}");
            Assert.IsTrue(mensaje.Contains("cargada") || mensaje.Contains("correctamente"), 
                $"Mensaje inesperado: {mensaje}");
        }

        /// <summary>
        /// Caso de Prueba #6: Consultar cliente inexistente
        /// Componente: Cargar()
        /// Valores de Entrada: CustomerID no registrado
        /// Valor de Salida Esperada: Cliente no encontrado
        /// ¿Ejecución Exitosa?: No
        /// Tipo de Error Detectado: Cliente no encontrado.
        /// Comentarios: Al mostrarse el mensaje de error, los campos permanecen vacíos y no se recibe ninguna información.
        /// </summary>
        [TestMethod]
        public void CP_006_ConsultarClienteInexistente()
        {
            // Arrange - Configurar CustomerID no registrado
            _negocioCliente.CustomerID = "XXXXX";

            // Act - Ejecutar consulta
            bool resultado = _negocioCliente.cargar(out string mensaje);

            // Assert - Verificar fallo
            Assert.IsFalse(resultado);
            Assert.AreEqual("Cliente no encontrado.", mensaje);
        }

        /// <summary>
        /// Caso de Prueba #7: Modificar datos de cliente existente
        /// Componente: Actualizar()
        /// Valores de Entrada: Datos válidos de cliente modificado
        /// Valor de Salida Esperada: Cliente actualizado correctamente.
        /// ¿Ejecución Exitosa?: Sí
        /// Tipo de Error Detectado: Ninguno.
        /// Comentarios: Los datos actualizados se reflejan exitosamente en el DataGrid
        /// </summary>
        [TestMethod]
        public void CP_007_ModificarDatosDeClienteExistente()
        {
            // Arrange - Primero insertar un cliente para luego modificarlo
            _negocioCliente.CustomerID = _testCustomerId;
            _negocioCliente.CompanyName = "Empresa Original";
            bool insertado = _negocioCliente.insertar(out string mensajeInsercion);
            
            // Si la inserción falla, saltar la prueba (problema de BD)
            if (!insertado)
            {
                Assert.Inconclusive($"No se pudo insertar cliente para prueba de modificación. Mensaje: {mensajeInsercion}");
                return;
            }

            // Configurar datos modificados
            _negocioCliente.CompanyName = "Empresa Modificada";

            // Act - Ejecutar modificación
            bool resultado = _negocioCliente.actualizar(out string mensaje);

            // Assert - Verificar éxito
            Assert.IsTrue(resultado, $"La modificación falló. Mensaje: {mensaje}");
            Assert.IsTrue(mensaje.Contains("actualizado") || mensaje.Contains("correctamente"), 
                $"Mensaje inesperado: {mensaje}");
        }

        /// <summary>
        /// Caso de Prueba #8: Modificar cliente inexistente o con datos erróneos
        /// Componente: Actualizar()
        /// Valores de Entrada: CustomerID inexistente / datos inválidos
        /// Valor de Salida Esperada: No se pudo actualizar el cliente.
        /// ¿Ejecución Exitosa?: No
        /// Tipo de Error Detectado: Cliente no encontrado / validación
        /// Comentarios: En la base de datos, algunos campos son obligatorios; por lo tanto, no pueden estar vacíos ni exceder la cantidad permitida de caracteres.
        /// </summary>
        [TestMethod]
        public void CP_008_ModificarClienteInexistenteOConDatosErroneos()
        {
            // Arrange - Configurar CustomerID inexistente / datos inválidos
            _negocioCliente.CustomerID = "XXXXX";
            _negocioCliente.CompanyName = "Empresa de Prueba";

            // Act - Ejecutar modificación
            bool resultado = _negocioCliente.actualizar(out string mensaje);

            // Assert - Verificar fallo
            Assert.IsFalse(resultado);
            Assert.AreEqual("No se pudo actualizar el cliente.", mensaje);
        }
    }
} 