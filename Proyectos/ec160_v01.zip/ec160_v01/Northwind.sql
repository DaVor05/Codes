-- 01_recreate_northwind.sql
-- ADVERTENCIA: Este script eliminar� la BD Northwind si existe y la recrear� limpia.
-- �salo solo si NO guardas datos importantes all�.

-- 1) Desconectar conexiones activas y eliminar la BD si existe
IF DB_ID('Northwind') IS NOT NULL
BEGIN
    ALTER DATABASE Northwind SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE Northwind;
END
GO

-- 2) Crear la base de datos
CREATE DATABASE Northwind;
GO

-- 3) Asegurar que la base est� ONLINE (evita error 945 si qued� OFFLINE)
ALTER DATABASE Northwind SET ONLINE;
GO

-- 4) Usar la base
USE Northwind;
GO

-- 5) Crear la tabla Customers
IF OBJECT_ID('dbo.Customers', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Customers (
        CustomerID NVARCHAR(5) PRIMARY KEY,
        CompanyName NVARCHAR(40) NOT NULL,
        ContactName NVARCHAR(30),
        ContactTitle NVARCHAR(30),
        Address NVARCHAR(60),
        City NVARCHAR(15),
        Region NVARCHAR(15),
        PostalCode NVARCHAR(10),
        Country NVARCHAR(15),
        Phone NVARCHAR(24),
        Fax NVARCHAR(24)
    );
END
GO

-- 6) Insertar datos de ejemplo (evitar duplicados)
IF NOT EXISTS (SELECT 1 FROM dbo.Customers WHERE CustomerID = 'ALFKI')
INSERT INTO dbo.Customers (CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax) VALUES
('ALFKI', 'Alfreds Futterkiste', 'Maria Anders', 'Sales Representative', 'Obere Str. 57', 'Berlin', NULL, '12209', 'Germany', '030-0074321', '030-0076545'),
('ANATR', 'Ana Trujillo Emparedados y helados', 'Ana Trujillo', 'Owner', 'Avda. de la Constituci�n 2222', 'M�xico D.F.', NULL, '05021', 'Mexico', '(5) 555-4729', '(5) 555-3745'),
('ANTON', 'Antonio Moreno Taquer�a', 'Antonio Moreno', 'Owner', 'Mataderos 2312', 'M�xico D.F.', NULL, '05023', 'Mexico', '(5) 555-3932', NULL),
('AROUT', 'Around the Horn', 'Thomas Hardy', 'Sales Representative', '120 Hanover Sq.', 'London', NULL, 'WA1 1DP', 'UK', '(171) 555-7788', '(171) 555-6750'),
('BERGS', 'Berglunds snabbk�p', 'Christina Berglund', 'Order Administrator', 'Berguvsv�gen 8', 'Lule�', NULL, 'S-958 22', 'Sweden', '0921-12 34 65', '0921-12 34 67');
GO
