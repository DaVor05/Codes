using Datos;

namespace Negocio
{
    // Clase Cliente: administra la lógica de negocio relacionada con clientes
    public class NegocioCliente : Customer
    {

        // ===== ATRIBUTOS PRIVADOS =====
        
        // Instancia para manejar el acceso a datos (base de datos)
        private readonly DataCliente _dataCliente;

        // Constructor que inicializa el objeto de acceso a datos
        public NegocioCliente()
        {
            _dataCliente = new DataCliente();
        }

        // ===== MÉTODOS DE LA CLASE =====

        // Método para cargar los datos de un cliente a partir de su ID
        public bool cargar(out string mensaje)
        {
            // Verifica si CustomerID está vacío o nulo antes de proceder
            if (string.IsNullOrWhiteSpace(this.CustomerID))
            {
                // Si no se proporciona CustomerID, retorna mensaje de error
                mensaje = "Debe proporcionar el CustomerID.";
                return false;
            }

            // Intenta cargar la información y retorna mensaje según resultado
            var resultado = _dataCliente.cargarCustomer(this);
            mensaje = resultado ? "Información del cliente cargada correctamente." : "Cliente no encontrado.";
            return resultado;
        }

        // Método para insertar un nuevo cliente en la base de datos
        public bool insertar(out string mensaje)
        {
            // Verifica que los campos obligatorios no estén vacíos antes de insertar
            if (string.IsNullOrWhiteSpace(this.CustomerID))
            {
                mensaje = "El CustomerID es obligatorio.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(this.CompanyName))
            {
                mensaje = "El nombre de la empresa es obligatorio.";
                return false;
            }

            // Intenta insertar el cliente y devuelve mensaje según éxito o fallo
            var resultado = _dataCliente.insertarCustomer(this);
            mensaje = resultado ? "Cliente insertado correctamente." : "No se pudo insertar el cliente.";
            return resultado;
        }

        // Método para eliminar un cliente usando su CustomerID
        public bool eliminar(out string mensaje)
        {
            if (string.IsNullOrWhiteSpace(this.CustomerID))
            {
                mensaje = "Debe proporcionar el CustomerID para eliminar.";
                return false;
            }

            // Intenta eliminar y notifica si fue exitoso o no
            var resultado = _dataCliente.eliminarCustomer(this.CustomerID);
            mensaje = resultado ? "Cliente eliminado correctamente." : "No se pudo eliminar el cliente.";
            return resultado;
        }

        // Método para actualizar los datos de un cliente existente
        public bool actualizar(out string mensaje)
        {
            if (string.IsNullOrWhiteSpace(this.CustomerID))
            {
                mensaje = "El CustomerID es obligatorio para actualizar.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(this.CompanyName))
            {
                mensaje = "El nombre de la empresa es obligatorio.";
                return false;
            }

            // Realiza la actualización y devuelve mensaje acorde al resultado
            var resultado = _dataCliente.actualizarCustomer(this);
            mensaje = resultado ? "Cliente actualizado correctamente." : "No se pudo actualizar el cliente.";
            return resultado;
        }

        // Método que devuelve la lista completa de clientes registrados
        public List<Customer> obtenerTodos()
        {
            return _dataCliente.obtenerTodosLosClientes();
        }
    }
}